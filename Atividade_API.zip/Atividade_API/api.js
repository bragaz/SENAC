async function getJoke() {
    try {
        const response = await fetch('https://official-joke-api.appspot.com/random_joke');
        const joke = await response.json();
        
        document.getElementById('setup').textContent = joke.setup;
        document.getElementById('punchline').textContent = joke.punchline;
    } catch (error) {
        document.getElementById('setup').textContent = "Erro ao obter piada";
        document.getElementById('punchline').textContent = "";
        console.error("Erro ao buscar a piada:", error);
    }
}

window.onload = getJoke;
