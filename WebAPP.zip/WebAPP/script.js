function novaPagina() {

    const mensagemElemento = document.getElementById("mensagem");

    mensagemElemento.innerText = "Você será redirecionado para outra página...";

    mensagemElemento.style.display = "block";
    
    setTimeout(function() {
      window.location.href = "tela1.html"; 
    }, 2000); 

    document.getElementById("mensagem").innerText = "Login Realizado com Sucesso.";

    
  }
  