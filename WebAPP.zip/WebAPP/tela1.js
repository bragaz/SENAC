document.addEventListener("DOMContentLoaded", function() {
    function loadPedidos() {
        const pedidosSalvos = JSON.parse(localStorage.getItem("pedidos")) || [];
        const pedidosList = document.getElementById("pedidosList");
        pedidosList.innerHTML = ""; 

        pedidosSalvos.forEach(function(pedido) {
            const li = document.createElement("li");
            li.textContent = `Mesa: ${pedido.mesa} - Produto: ${pedido.produto} - Quantidade: ${pedido.quantidade}`;
            pedidosList.appendChild(li);
        });
    }

    function savePedido(mesa, produto, quantidade) {
        const pedidosSalvos = JSON.parse(localStorage.getItem("pedidos")) || [];
        pedidosSalvos.push({ mesa, produto, quantidade });
        localStorage.setItem("pedidos", JSON.stringify(pedidosSalvos));
    }

    function clearPedidos() {
        localStorage.removeItem("pedidos");
        document.getElementById("pedidosList").innerHTML = ""; 
    }

    document.getElementById("pedidoForm").addEventListener("submit", function(event) {
        event.preventDefault();

        const mesa = document.getElementById("mesa").value.trim();
        const produto = document.getElementById("produto").value.trim();
        const quantidade = document.getElementById("quantidade").value.trim();

        if (mesa && produto && quantidade) {
            savePedido(mesa, produto, quantidade);

            const li = document.createElement("li");
            li.textContent = `Mesa: ${mesa} - Produto: ${produto} - Quantidade: ${quantidade}`;
            document.getElementById("pedidosList").appendChild(li);

            document.getElementById("mesa").value = "";
            document.getElementById("produto").value = "";
            document.getElementById("quantidade").value = "";
        } else {
            alert("Por favor, preencha todos os campos.");
        }
    });

    document.getElementById("limparPedidos").addEventListener("click", function() {
        if (confirm("Você tem certeza que deseja limpar todos os pedidos?")) {
            clearPedidos();
        }
    });

    loadPedidos();
});
